<?php
$loader = require_once __DIR__ . "/../vendor/autoload.php";
$loader->add('ChrisAllen\\TicTacToe\\', __DIR__);